package com.guardian.staff.application.usecase;

import com.guardian.common.audit.AuditPort;
import com.guardian.common.audit.AuditRecord;
import com.guardian.common.error.ErrorCode;
import com.guardian.common.error.ResourceNotFoundException;
import com.guardian.common.tenant.TenantContext;
import com.guardian.common.tenant.TenantId;
import com.guardian.staff.application.command.UpdateTransportStaffCommand;
import com.guardian.staff.application.port.TransportStaffRepository;
import com.guardian.staff.domain.TransportStaff;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Updates a staff member's contact details (feature STF-001).
 *
 * <p>{@code staffType} and {@code verificationStatus} are not editable here. A type change would
 * silently invalidate credential-class checks already recorded against this staff member; a
 * verification change goes through {@link VerifyStaffUseCase} so the required {@code
 * verifiedUntil} date and the audit trail stay coupled (BR-STAFF-002).
 */
@Service
public class UpdateTransportStaffUseCase {

  private final TransportStaffRepository staffRepository;
  private final AuditPort auditPort;

  public UpdateTransportStaffUseCase(TransportStaffRepository staffRepository, AuditPort auditPort) {
    this.staffRepository = staffRepository;
    this.auditPort = auditPort;
  }

  @Transactional
  public TransportStaff execute(UpdateTransportStaffCommand command) {
    TenantId tenantId = TenantContext.require();

    TransportStaff existing =
        staffRepository
            .findById(command.staffId())
            .orElseThrow(
                () ->
                    new ResourceNotFoundException(
                        ErrorCode.STAFF_NOT_FOUND, "TransportStaff", command.staffId().value()));

    TransportStaff updated =
        existing.updateDetails(command.firstName(), command.lastName(), command.phone());
    TransportStaff saved = staffRepository.save(updated);

    // Names and phone are PII (CODING_STANDARDS_BACKEND.md) — the audit record notes that
    // contact details changed without echoing the values themselves.
    auditPort.record(
        AuditRecord.builder()
            .tenantId(tenantId)
            .actor(command.actorId(), AuditRecord.ActorType.USER, command.actorRole())
            .action("TRANSPORT_STAFF_UPDATED")
            .subject("TransportStaff", saved.id().value())
            .after(Map.of("fieldsChanged", "firstName,lastName,phone"))
            .build());

    return saved;
  }
}
