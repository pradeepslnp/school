package com.guardian.staff.application.usecase;

import com.guardian.common.BusinessRule;
import com.guardian.common.audit.AuditPort;
import com.guardian.common.audit.AuditRecord;
import com.guardian.common.tenant.TenantContext;
import com.guardian.common.tenant.TenantId;
import com.guardian.staff.application.command.CreateTransportStaffCommand;
import com.guardian.staff.application.port.TransportStaffRepository;
import com.guardian.staff.domain.TransportStaff;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Registers a driver or attendant, pending verification (feature STF-001).
 *
 * <p>One class, one operation. Constructor injection only, all dependencies final
 * (guardian-docs/ENGINEERING_PRINCIPLES.md §5).
 *
 * <p>{@code employee_code} uniqueness within a school (MOD-05-06-fleet-staff.md) is enforced by
 * the database's partial unique index, not re-checked here — a race between two concurrent
 * creations is resolved by the constraint, and the adapter translates the resulting violation
 * into {@code STAFF_EMPLOYEE_CODE_EXISTS}. Unlike a vehicle's registration number, this is not
 * cited as a business-rule check: it is a data-integrity constraint, not a documented BR.
 */
@Service
@BusinessRule("BR-AUD-002")
public class CreateTransportStaffUseCase {

  private final TransportStaffRepository staffRepository;
  private final AuditPort auditPort;

  public CreateTransportStaffUseCase(TransportStaffRepository staffRepository, AuditPort auditPort) {
    this.staffRepository = staffRepository;
    this.auditPort = auditPort;
  }

  @Transactional
  public TransportStaff execute(CreateTransportStaffCommand command) {
    TenantId tenantId = TenantContext.require();

    TransportStaff staff =
        TransportStaff.create(
            tenantId,
            command.schoolId(),
            command.staffType(),
            command.employeeCode(),
            command.firstName(),
            command.lastName(),
            command.phone(),
            command.vendorName());

    TransportStaff saved = staffRepository.save(staff);

    // BR-AUD-002: the audit write shares this transaction. If it fails, the staff record is not
    // created — the platform refuses an operation rather than performing it unrecorded.
    auditPort.record(
        AuditRecord.builder()
            .tenantId(tenantId)
            .actor(command.actorId(), AuditRecord.ActorType.USER, command.actorRole())
            .action("TRANSPORT_STAFF_CREATED")
            .subject("TransportStaff", saved.id().value())
            .after(describe(saved))
            .build());

    return saved;
  }

  private static Map<String, Object> describe(TransportStaff staff) {
    Map<String, Object> values = new LinkedHashMap<>();
    values.put("staffType", staff.staffType().name());
    values.put("employeeCode", staff.employeeCode().orElse(null));
    values.put("verificationStatus", staff.verificationStatus().name());
    return values;
  }
}
