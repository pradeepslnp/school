package com.guardian.common.error;

/**
 * Stable error identifiers returned to clients.
 *
 * <p>Every value here must appear in guardian-docs/04-api/ERROR_CATALOG.md with its HTTP status and
 * business rule — a CI check fails the build otherwise. Codes are never reused for a different
 * meaning.
 *
 * <p>Carries no user-facing text: {@link #messageKey()} names a localisation resource (BR-CFG-005).
 */
public enum ErrorCode {

  // --- Authentication & authorization -------------------------------------------------
  AUTH_CREDENTIALS_INVALID(401),
  AUTH_TOKEN_MISSING(401),
  AUTH_TOKEN_EXPIRED(401),
  AUTH_TOKEN_INVALID(401),
  AUTH_SESSION_REVOKED(401),
  AUTH_REFRESH_REUSE_DETECTED(401),
  AUTH_ACCOUNT_LOCKED(401),
  // Both mean the code can never succeed however it is retyped, which is why they are
  // distinct from AUTH_CREDENTIALS_INVALID: the client sends the guardian back for a fresh
  // code rather than letting them retype into a dead field.
  AUTH_OTP_EXPIRED(401),
  AUTH_OTP_ALREADY_USED(401),
  AUTH_PERMISSION_DENIED(403),
  AUTH_SCOPE_DENIED(403),
  AUTH_TENANT_MISMATCH(404),
  AUTH_JUSTIFICATION_REQUIRED(403),

  // --- Validation ---------------------------------------------------------------------
  VALIDATION_FAILED(400),
  VALIDATION_REQUIRED_FIELD_MISSING(400),
  VALIDATION_INVALID_FORMAT(400),
  VALIDATION_VALUE_OUT_OF_RANGE(400),

  // --- Tenancy ------------------------------------------------------------------------
  ORG_CODE_ALREADY_EXISTS(409),
  ORG_SUSPENDED(403),
  ORG_LAST_SCHOOL_CANNOT_BE_REMOVED(422),
  SCHOOL_CODE_ALREADY_EXISTS(409),
  SCHOOL_CANNOT_CHANGE_ORGANIZATION(422),
  SCHOOL_NOT_FOUND(404),
  ORGANIZATION_NOT_FOUND(404),

  // --- Students & guardians -------------------------------------------------------------
  // 403, not 422: the caller lacks the handover right on the relationship, which is an
  // authorisation fact rather than a malformed nomination (BR-GRD-006).
  GUARDIAN_NOT_AUTHORISED_TO_NOMINATE(403),
  PICKUP_PERSON_OUTSIDE_VALIDITY(422),
  PICKUP_PERSON_REVOKED(422),
  // Same underlying right as GUARDIAN_NOT_AUTHORISED_TO_NOMINATE (can_authorise_handover,
  // BR-GRD-006) but a distinct code: this guards *requesting a release code*, not nominating
  // a pickup person, and a client should never have to infer which action a shared code means.
  GUARDIAN_NOT_AUTHORISED_FOR_HANDOVER(403),

  // --- Absence ----------------------------------------------------------------------------
  // The manifest is already materialised and immutable; a change after this point is a
  // manifest amendment by staff, not a parent's declaration (BR-ABS-003).
  ABSENCE_TRIP_ALREADY_STARTED(422),

  // --- System -------------------------------------------------------------------------
  RATE_LIMIT_EXCEEDED(429),
  TENANT_CONTEXT_MISSING(500),
  INTERNAL_ERROR(500);

  private final int httpStatus;

  ErrorCode(int httpStatus) {
    this.httpStatus = httpStatus;
  }

  public int httpStatus() {
    return httpStatus;
  }

  /**
   * The localisation key for this code — {@code error.auth.credentials_invalid}.
   *
   * <p>Clients display from this, never from a server-supplied message (BR-CFG-005).
   */
  public String messageKey() {
    return "error." + name().toLowerCase(java.util.Locale.ROOT);
  }
}
