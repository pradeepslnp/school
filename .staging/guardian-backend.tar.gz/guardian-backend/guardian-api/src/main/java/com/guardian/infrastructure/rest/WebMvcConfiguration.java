package com.guardian.infrastructure.rest;

import java.util.List;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Registers the platform's controller argument resolvers.
 *
 * <p>Currently one: {@link CurrentActorArgumentResolver}. Registration is not optional — an
 * unregistered resolver leaves {@code CurrentActor} parameters to Spring's default model-attribute
 * binding, which would populate them from the request. See that class for why that is an
 * impersonation hole rather than a binding quirk.
 */
@Configuration
public class WebMvcConfiguration implements WebMvcConfigurer {

  private final CurrentActorArgumentResolver currentActorArgumentResolver;

  public WebMvcConfiguration(CurrentActorArgumentResolver currentActorArgumentResolver) {
    this.currentActorArgumentResolver = currentActorArgumentResolver;
  }

  @Override
  public void addArgumentResolvers(List<HandlerMethodArgumentResolver> resolvers) {
    // Added ahead of Spring's defaults: custom resolvers are consulted first, so this wins over
    // model-attribute binding for the same parameter type.
    resolvers.add(currentActorArgumentResolver);
  }
}
