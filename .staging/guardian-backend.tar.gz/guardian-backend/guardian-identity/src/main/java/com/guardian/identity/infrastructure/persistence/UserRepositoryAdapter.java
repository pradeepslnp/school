package com.guardian.identity.infrastructure.persistence;

import com.guardian.identity.application.port.UserRepository;
import com.guardian.identity.domain.PhoneNumber;
import com.guardian.identity.domain.User;
import com.guardian.identity.domain.UserId;
import com.guardian.identity.domain.UserStatus;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Component;

/** Implements {@link UserRepository} over JPA. */
@Component
class UserRepositoryAdapter implements UserRepository {

  private final UserJpaRepository jpaRepository;

  UserRepositoryAdapter(UserJpaRepository jpaRepository) {
    this.jpaRepository = jpaRepository;
  }

  @Override
  public Optional<User> findById(UserId id) {
    return jpaRepository.findById(id.value()).map(UserRepositoryAdapter::toDomain);
  }

  @Override
  public List<String> roleCodesOf(UserId id) {
    return jpaRepository.findRoleCodes(id.value());
  }

  @Override
  public User save(User user) {
    // Loads the managed instance and mutates it, rather than persisting a detached copy: only
    // then do Hibernate's dirty checking and @Version apply. A detached save would bypass
    // optimistic locking and let a concurrent administrative edit be silently overwritten by a
    // sign-in.
    UserEntity entity =
        jpaRepository
            .findById(user.id().value())
            .orElseThrow(
                () ->
                    new IllegalStateException(
                        "user " + user.id() + " disappeared between read and write"));

    entity.applySignIn(user.lastLoginAt());
    return toDomain(jpaRepository.save(entity));
  }

  private static User toDomain(UserEntity entity) {
    return User.rehydrate(
        UserId.of(entity.getId()),
        entity.getPhone() == null ? null : new PhoneNumber(entity.getPhone()),
        entity.getEmail(),
        entity.getFirstName(),
        entity.getLastName(),
        entity.getPreferredLocale(),
        UserStatus.fromStored(entity.getStatus()),
        entity.getLastLoginAt(),
        entity.getVersion());
  }
}
