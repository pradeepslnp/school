package com.guardian.identity.application;

import com.guardian.common.tenant.TenantContext;
import com.guardian.common.tenant.TenantId;
import java.util.function.Supplier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * Runs work in a transaction whose database connection carries a tenant that was resolved a moment
 * earlier, rather than one established by the request filter.
 *
 * <p>This exists only for authentication. Every other operation in the platform inherits its tenant
 * from the authenticated principal via {@code TenantContextFilter}, long before any use case runs.
 * Sign-in is the one place where the tenant is discovered mid-request — by {@link
 * com.guardian.identity.application.port.PreAuthenticationDirectory} — and everything after that
 * discovery must run under it.
 *
 * <p><strong>The nesting order is the whole point and is easy to get backwards.</strong> {@code
 * TenantAwareDataSource} issues {@code SET LOCAL app.tenant_id} when a connection is handed out,
 * reading {@link TenantContext} at that instant. A transaction acquires its connection as it
 * begins. So the context must be set <em>outside</em> the transaction:
 *
 * <pre>{@code
 * TenantContext.runAs(tenantId, () -> transactionTemplate.execute(...))   // correct
 * transactionTemplate.execute(status -> TenantContext.runAs(tenantId, ...))  // silently broken
 * }</pre>
 *
 * <p>Written the second way, the connection is acquired while the context is still empty, {@code
 * SET LOCAL} never runs, and every statement inside meets an RLS predicate comparing against NULL.
 * Reads return nothing and writes are refused — with no error naming the cause. It looks like a
 * missing row.
 *
 * <p>A programmatic {@link TransactionTemplate} rather than {@code @Transactional} for the same
 * reason: an annotation on a method of the calling class would be applied by a proxy at the call
 * boundary, which is before {@code runAs} has a chance to run.
 */
@Component
public class TenantScopedTransaction {

  private final TransactionTemplate transactionTemplate;

  public TenantScopedTransaction(TransactionTemplate transactionTemplate) {
    this.transactionTemplate = transactionTemplate;
  }

  public <T> T execute(TenantId tenantId, Supplier<T> action) {
    return TenantContext.runAs(tenantId, () -> transactionTemplate.execute(status -> action.get()));
  }
}
