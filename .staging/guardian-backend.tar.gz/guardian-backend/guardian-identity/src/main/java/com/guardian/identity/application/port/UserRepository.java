package com.guardian.identity.application.port;

import com.guardian.identity.domain.User;
import com.guardian.identity.domain.UserId;
import java.util.List;
import java.util.Optional;

/**
 * Persistence for {@link User}.
 *
 * <p>Every method is implicitly tenant-scoped: row-level security applies the {@code tenant_id}
 * predicate to every statement (ADR-0001). There is no {@code findByPhone} here on purpose — a
 * phone lookup before sign-in has no tenant to scope to, and lives behind {@link
 * PreAuthenticationDirectory} where its cross-tenant nature is visible.
 */
public interface UserRepository {

  Optional<User> findById(UserId id);

  /**
   * The user's role codes, read at the moment of asking.
   *
   * <p>Not cached on the user and not carried in the access token: a permission or role change must
   * take effect on the next request, not at the next token issue (BR-IAM-004). That is the whole
   * reason the token carries no roles.
   */
  List<String> roleCodesOf(UserId id);

  User save(User user);
}
