# INSTRUCTIONS

**Document tier:** 0 — Governance
**Status:** Active
**Authority:** This is the highest-priority document in the repository. Where any other document conflicts with this one, this document wins.

---

## Purpose

This repository contains the official documentation and source code for the **Guardian Platform**, a multi-tenant student safety and transport system for schools.

This document defines the process every contributor — human or AI — follows before answering a question, writing code, or changing documentation.

---

## STEP 1 — Read Project Context

Always identify the relevant project documents before answering.

Priority order:

1. `INSTRUCTIONS.md` (this document)
2. `AI_MASTER_PROMPT.md`
3. `PROJECT_CHARTER.md`
4. `ENGINEERING_PRINCIPLES.md`
5. `PRODUCT_PRINCIPLES.md`
6. Relevant Product Discovery documents — [`guardian-docs/01-product-discovery/`](01-product-discovery/)
7. Relevant System Design documents — [`guardian-docs/02-system-design/`](02-system-design/)
8. Relevant API documents — [`guardian-docs/04-api/`](04-api/)
9. Relevant Database documents — [`guardian-docs/03-database/`](03-database/)
10. Relevant UI documents — [`guardian-docs/05-ui/`](05-ui/)
11. Relevant Development documents — [`guardian-docs/06-development/`](06-development/)
12. Flutter App instructions — [`guardian-docs/FLUTTER_APP_INSTRUCTIONS.md`](FLUTTER_APP_INSTRUCTIONS.md)

Never ignore existing documentation.

---

## STEP 2 — Verify Requirement

Before writing code or documentation, understand the request and determine:

- Which module is affected — see [`MODULE_MAP.md`](01-product-discovery/MODULE_MAP.md)
- Which stakeholders are affected — see [`STAKEHOLDERS.md`](01-product-discovery/STAKEHOLDERS.md)
- Which business rules apply — see [`BUSINESS_RULES.md`](01-product-discovery/BUSINESS_RULES.md)
- Which APIs are affected
- Which database tables are affected
- Which UI screens are affected
- Which permissions are affected — see [`PERMISSION_MATRIX.md`](01-product-discovery/PERMISSION_MATRIX.md)
- Which notifications are affected — see [`NOTIFICATION_CATALOG.md`](01-product-discovery/NOTIFICATION_CATALOG.md)

**If information is missing, ask questions instead of making assumptions.**

---

## STEP 3 — Follow Project Principles

Every response must uphold:

| Principle | Meaning |
|---|---|
| Child Safety First | When a trade-off exists, the option that better protects a child wins — even at the cost of convenience, performance, or elegance. |
| Parent Peace of Mind | Parents receive timely, accurate, non-alarming information about their child. |
| School Operational Efficiency | Staff workflows minimise manual effort and cognitive load. |
| Enterprise Scalability | Designs work for one school and for a group of five hundred. |
| Security by Design | Security is a design input, never a later addition. |
| Configuration over Hardcoding | Behaviour that varies by tenant, region, or policy lives in configuration. |
| Multi-Tenant Architecture | Tenant isolation is enforced structurally, not by convention. |
| Auditability | Every safety-relevant action is attributable to an actor and a time. |
| Maintainability | Optimise for the reader, not the writer. |
| Production Quality | No placeholders, no pseudo-production code, no "temporary" shortcuts. |

Full detail: [`PRODUCT_PRINCIPLES.md`](PRODUCT_PRINCIPLES.md) and [`ENGINEERING_PRINCIPLES.md`](ENGINEERING_PRINCIPLES.md).

---

## STEP 4 — Follow Engineering Standards

All solutions follow: Clean Architecture, SOLID, DRY, KISS, Feature-First Architecture, Repository Pattern, Dependency Injection, Modular Design, Layer Separation, Single Responsibility.

- **Never mix business logic into UI.**
- **Never duplicate business logic.**

See [`ENGINEERING_PRINCIPLES.md`](ENGINEERING_PRINCIPLES.md) and [`guardian-docs/06-development/`](06-development/).

---

## STEP 5 — Before Coding

Explain, in this order: overall approach, business impact, database impact, API impact, UI impact, security impact, testing impact.

Then generate code.

---

## STEP 6 — After Coding

Verify: business rules · validation · authorization · error handling · logging · audit trail · performance · security · scalability · testability.

See [`guardian-docs/06-development/DEFINITION_OF_DONE.md`](06-development/DEFINITION_OF_DONE.md), and [Current Exception — Flutter tests](#current-exception--flutter-tests) below.

---

## Current Exception — Flutter tests

**Do not write new Flutter test classes.** Delivery is focused on the backend API and database; widget tests written against an API shape that is still settling would be rewritten rather than reused.

Still applies:
- Existing Flutter tests stay and must keep passing.
- `flutter analyze` stays clean.
- `guardian_core` stays tested — it is pure Dart and every client depends on it.
- No business logic in widgets ([`ENGINEERING_PRINCIPLES.md`](ENGINEERING_PRINCIPLES.md) §8). That is what keeps the untested layer thin.
- Backend tests remain mandatory.

Revisit when the driver app starts consuming real endpoints. The 🔴 safety-critical screens — boarding, handover, SOS, reconciliation — are not covered by this and still require the coverage in [`SAFETY_CRITICAL_TEST_MATRIX.md`](07-testing/SAFETY_CRITICAL_TEST_MATRIX.md).

---

## Document Hierarchy

```
INSTRUCTIONS.md
   ↓
PROJECT_CHARTER.md
   ↓
Business Rules
   ↓
Feature Inventory
   ↓
System Design
   ↓
Database
   ↓
API
   ↓
UI
   ↓
Development
   ↓
Testing
   ↓
Deployment
```

If two documents conflict, **the higher-priority document wins**. Never invent requirements.

Full detail: [`guardian-docs/00-governance/DOCUMENT_HIERARCHY.md`](00-governance/DOCUMENT_HIERARCHY.md).

---

## Response Format

When responding to any development request, cover:

1. Requirement Summary
2. Documents Referenced
3. Business Rules Applied
4. Proposed Solution
5. Impact Analysis
6. Implementation
7. Test Cases
8. Future Considerations

Never skip these sections unless the user explicitly requests only code.

---

## Documentation Rule

Whenever a new business rule, feature, module, or architectural decision is introduced, recommend:

- Which document should be updated
- Which new document should be created, if required
- Which existing documents may be affected

Architectural decisions are recorded as ADRs in [`guardian-docs/00-governance/adr/`](00-governance/adr/).

Documentation is always the single source of truth.

---

## Quality Rule

- Never generate placeholder code.
- Never generate pseudo-production code.
- Never sacrifice architecture for speed.
- Always optimise for readability, maintainability, scalability, and long-term support.

---

## Project Memory

This is a long-term enterprise project. Maintain consistency with all previous architectural decisions. Never redesign an existing module without explaining why. Always extend the architecture rather than break it.

---

## Final Rule

For any question related to this project:

1. Read the project instructions.
2. Read the relevant documentation.
3. Explain your reasoning.
4. Follow project standards.
5. Produce enterprise-quality output.
6. **If documentation is missing, recommend creating or updating it before implementation.**
