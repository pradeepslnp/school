-- V7 — Fleet (MOD-05)
--
-- Row-level security is applied HERE, in the same migration that creates the tables — never
-- in a follow-up. A table that exists for even one deploy without a policy is a table that
-- was readable across tenants for that deploy.
--
-- See guardian-docs/03-database/tables/MOD-05-06-fleet-staff.md and
-- guardian-docs/03-database/RLS_POLICIES.md.

-- ---------------------------------------------------------------------------------------
-- vehicles
-- ---------------------------------------------------------------------------------------
CREATE TABLE vehicles (
    id                UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID         NOT NULL REFERENCES organizations (id) ON DELETE RESTRICT,
    school_id         UUID         NOT NULL REFERENCES schools (id) ON DELETE RESTRICT,
    registration_no   VARCHAR(32)  NOT NULL,
    -- What parents see in notifications — "Bus 12", not a plate number (NTF-BOARD-01).
    display_name      VARCHAR(64)  NOT NULL,
    vehicle_type      VARCHAR(24)  NOT NULL,
    seating_capacity  INTEGER      NOT NULL,
    vendor_name       VARCHAR(255),
    status            VARCHAR(24)  NOT NULL DEFAULT 'ACTIVE',
    created_at        TIMESTAMPTZ  NOT NULL DEFAULT now(),
    created_by        UUID,
    updated_at        TIMESTAMPTZ  NOT NULL DEFAULT now(),
    updated_by        UUID,
    version           BIGINT       NOT NULL DEFAULT 0,

    -- BR-FLEET-001: unique within the organization. tenant_id IS the organization (ADR-0002).
    CONSTRAINT uq_vehicles_registration UNIQUE (tenant_id, registration_no),
    CONSTRAINT ck_vehicles_capacity     CHECK (seating_capacity > 0),
    CONSTRAINT ck_vehicles_type         CHECK (vehicle_type IN ('BUS', 'VAN', 'MINIBUS')),
    CONSTRAINT ck_vehicles_status       CHECK (status IN ('ACTIVE', 'MAINTENANCE', 'RETIRED'))
);

CREATE INDEX idx_vehicles_tenant_school ON vehicles (tenant_id, school_id)
    WHERE status = 'ACTIVE';

-- ---------------------------------------------------------------------------------------
-- vehicle_documents — compliance artefacts; expiry blocks trip assignment (BR-FLEET-002 🔴)
-- ---------------------------------------------------------------------------------------
CREATE TABLE vehicle_documents (
    id              UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID         NOT NULL REFERENCES organizations (id) ON DELETE RESTRICT,
    vehicle_id      UUID         NOT NULL REFERENCES vehicles (id) ON DELETE RESTRICT,
    -- Free-form against region reference data, not a database enum (ADR-0007). Registration,
    -- fitness, insurance, and permit types differ by country; a code enum here would mean a
    -- code change to onboard a new market.
    document_type   VARCHAR(48)  NOT NULL,
    document_number VARCHAR(128),
    issued_on       DATE,
    expires_on      DATE         NOT NULL,
    is_mandatory    BOOLEAN      NOT NULL,
    file_ref        VARCHAR(255),
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT now(),
    created_by      UUID,
    updated_at      TIMESTAMPTZ  NOT NULL DEFAULT now(),
    updated_by      UUID,
    version         BIGINT       NOT NULL DEFAULT 0,

    CONSTRAINT ck_vehicle_documents_dates CHECK (issued_on IS NULL OR expires_on > issued_on)
);

CREATE INDEX idx_vehicle_documents_expiry ON vehicle_documents (tenant_id, expires_on)
    WHERE is_mandatory;

-- ---------------------------------------------------------------------------------------
-- devices — GPS tracking devices (ADR-0004), optionally assigned to a vehicle
-- ---------------------------------------------------------------------------------------
CREATE TABLE devices (
    id                UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID         NOT NULL REFERENCES organizations (id) ON DELETE RESTRICT,
    vehicle_id        UUID         REFERENCES vehicles (id) ON DELETE RESTRICT,
    device_identifier VARCHAR(128) NOT NULL,
    vendor_code       VARCHAR(48)  NOT NULL,
    credential_hash   VARCHAR(255) NOT NULL,
    last_seen_at      TIMESTAMPTZ,
    is_active         BOOLEAN      NOT NULL DEFAULT true,
    created_at        TIMESTAMPTZ  NOT NULL DEFAULT now(),
    created_by        UUID,
    updated_at        TIMESTAMPTZ  NOT NULL DEFAULT now(),
    updated_by        UUID,
    version           BIGINT       NOT NULL DEFAULT 0,

    -- Globally unique, not scoped to tenant_id: ingestion resolves the device before it knows
    -- the tenant (guardian-docs/02-system-design/REALTIME_TRACKING_DESIGN.md).
    CONSTRAINT uq_devices_identifier UNIQUE (device_identifier),
    -- BR-FLEET-004 🔴, enforced structurally: at most one active device per vehicle. Two
    -- devices reporting for one bus would produce contradictory positions.
    CONSTRAINT uq_devices_vehicle_active UNIQUE (tenant_id, vehicle_id) WHERE is_active
);

CREATE INDEX idx_devices_tenant ON devices (tenant_id) WHERE is_active;

-- ---------------------------------------------------------------------------------------
-- Row-level security — see V1__baseline_tenancy.sql for the rationale of each clause.
-- ---------------------------------------------------------------------------------------

ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehicles FORCE  ROW LEVEL SECURITY;

CREATE POLICY tenant_isolation ON vehicles
    FOR ALL
    USING      (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
    WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

ALTER TABLE vehicle_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehicle_documents FORCE  ROW LEVEL SECURITY;

CREATE POLICY tenant_isolation ON vehicle_documents
    FOR ALL
    USING      (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
    WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

ALTER TABLE devices ENABLE ROW LEVEL SECURITY;
ALTER TABLE devices FORCE  ROW LEVEL SECURITY;

-- Same policy shape as every other tenant-scoped table, per RLS_POLICIES.md's table list
-- ("Fleet: vehicles · vehicle_documents · devices").
--
-- OPEN QUESTION, left to MOD-10 (Tracking, not yet built): device_identifier is deliberately
-- global (see the unique constraint above) so ingestion can resolve a device before it knows
-- the tenant — but this policy means a lookup with no tenant context set returns zero rows,
-- same as any other tenant-scoped table. How the ingestion pipeline learns a tenant_id to set
-- before its first tenant-scoped read is not addressed by REALTIME_TRACKING_DESIGN.md as it
-- stands today and must be resolved — via a bounded, audited platform-operations-style path
-- (BR-TEN-004), not by adding a code path that turns RLS off — before MOD-10 ingests a single
-- position. Recorded here rather than guessed at, so it is not silently designed twice.
CREATE POLICY tenant_isolation ON devices
    FOR ALL
    USING      (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
    WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);

GRANT SELECT, INSERT, UPDATE, DELETE
    ON vehicles, vehicle_documents, devices
    TO guardian_app;
